const sessions = [
  {
    id: 'juin-2026', date: '29 juin 2026', headline: '12 questions à l’ordre du jour',
    stats: ['11 adoptées', '1 reportée', 'questions diverses'], open: true,
    pdf: 'assets/documents/pv-conseil-29-juin-2026.pdf',
    intro: 'Énergie, patrimoine, sécurité civile, services municipaux et plusieurs annonces sur les travaux et les équipements.',
    items: [
      { ref:'01', kind:'Délibération', title:'Don de 50 000 € pour l’église de Richet', summary:'La commune accepte le don des Amis de l’Église de Richet pour financer les peintures murales.', result:'Unanimité', vote:'Pour', opinion:'Ce financement réduit le reste à charge communal. Nous suivrons le coût total et le calendrier du chantier.', theme:'Patrimoine & vie locale' },
      { ref:'02', kind:'Délibération', title:'Tarifs de la remorque communale', summary:'160 € le week-end, 80 € la demi-journée et 1 000 € de caution pour la remorque destinée aux déchets verts.', result:'Unanimité', vote:'Pour', opinion:'Le service et les tarifs nous paraissent cohérents. Adrien Tordeur a demandé que son existence soit mieux expliquée aux habitants.', theme:'Proximité & sécurité' },
      { ref:'03', kind:'Délibération', title:'Règlement de la médiathèque', summary:'Le règlement est approuvé, avec une caution de 30 € pour les résidents saisonniers.', result:'Unanimité', vote:'Pour', opinion:'Le dispositif protège les collections tout en maintenant un accès simple au service.', theme:'Patrimoine & vie locale' },
      { ref:'04', kind:'Délibération', title:'Restauration des peintures de Richet', summary:'Les travaux sont autorisés et la consultation des entreprises peut commencer.', result:'Unanimité', vote:'Pour', opinion:'La restauration répond à une priorité patrimoniale partagée. Le plan de financement devra être suivi jusqu’à la fin du chantier.', theme:'Patrimoine & vie locale' },
      { ref:'05', kind:'Délibération', title:'Rénovation énergétique d’un logement communal', summary:'La commune demande une aide du Fonds Vert pour un projet estimé à 136 626 € HT, route des Lacs.', result:'Unanimité', vote:'Pour', opinion:'Réduire les consommations va dans le bon sens. Nous demanderons le montant de la subvention, le reste à charge et les économies réellement obtenues.', theme:'Environnement, énergie & forêt' },
      { ref:'06', kind:'Délibération', title:'Délégations données au maire', summary:'La délibération du 30 mars est corrigée pour préciser les limites réglementaires des délégations.', result:'Unanimité', vote:'Pour', opinion:'La correction juridique était nécessaire. L’usage de ces délégations doit être rapporté clairement et régulièrement au conseil.', theme:'Gouvernance & transparence' },
      { ref:'07', kind:'Délibération', title:'Correspondant Défense', summary:'Xavier Bertrand est désigné correspondant Défense.', result:'Unanimité', vote:'Pour', opinion:'Cette fonction institutionnelle crée un relais local pour l’information, la mémoire et les questions de défense.', theme:'Proximité & sécurité' },
      { ref:'08', kind:'Délibération', title:'Réserve communale de sécurité civile', summary:'La réserve communale et son règlement sont actualisés après le renouvellement du conseil.', result:'Unanimité', vote:'Pour', opinion:'Préparer les bénévoles et l’appui à la population est essentiel en cas de crise.', theme:'Proximité & sécurité' },
      { ref:'09', kind:'Délibération', title:'Plan communal de sauvegarde', summary:'L’organisation communale prévue en cas de crise est mise à jour.', result:'Unanimité', vote:'Pour', opinion:'Un plan opérationnel protège les habitants. Les consignes utiles doivent aussi être facilement accessibles au public.', theme:'Proximité & sécurité' },
      { ref:'10', kind:'Délibération', title:'Refonte du site internet municipal', summary:'Le site sera refait par l’ALPI : 910 € par an, 1 500 € de création et 1 950 € pour l’audit d’accessibilité.', result:'Unanimité', vote:'Pour', opinion:'Un site clair et accessible est nécessaire. Nous suivrons ses fonctions concrètes, son coût annuel et la publication des décisions.', theme:'Gouvernance & transparence' },
      { ref:'11', kind:'Délibération', title:'Modalités des astreintes', summary:'Le Comité social territorial n’ayant pas pu rendre son avis faute de quorum, la question reviendra plus tard.', result:'Reportée', vote:'Pas de vote', opinion:'Une question reportée n’est pas une décision. Elle devra revenir au conseil après l’avis obligatoire.', theme:'Gouvernance & transparence' },
      { ref:'12', kind:'Délibération', title:'Régime indemnitaire des agents', summary:'Le RIFSEEP est actualisé pour les titulaires, stagiaires et contractuels.', result:'Unanimité', vote:'Pour', opinion:'Nous soutenons un cadre qui reconnaît les responsabilités et l’engagement, avec une application équitable et lisible.', theme:'Gouvernance & transparence' },
      { ref:'A', kind:'Information', title:'Aire de jeux derrière la piscine', summary:'Le maire annonce que le projet est validé et que les équipements sont commandés.', result:'Information donnée', vote:'Pas de vote', opinion:'Le projet correspond au programme de la majorité. Son coût et son calendrier n’ont pas été soumis au vote pendant cette séance.', theme:'Enfance & jeunesse' },
      { ref:'B', kind:'Information', title:'Chaleur dans les écoles', summary:'Capteurs de CO₂, adaptation de la toiture, climatisation de l’accueil périscolaire, travaux électriques et photovoltaïque sont évoqués.', result:'Information donnée', vote:'Pas de vote', opinion:'Ces adaptations sont utiles. Nous resterons attentifs au calendrier, au confort réellement gagné et à la coordination avec l’intercommunalité.', theme:'Enfance & jeunesse' },
      { ref:'C', kind:'Information', title:'Travaux communaux annoncés', summary:'Extension du kinésithérapeute, sanitaires extérieurs de la piscine, rénovation énergétique, piscine et deuxième phase de Richet.', result:'Information donnée', vote:'Pas de vote', opinion:'Nous suivrons les calendriers et les budgets, notamment pour la piscine dont les travaux sont annoncés au premier semestre 2027.', theme:'Patrimoine & vie locale' },
      { ref:'D', kind:'Information', title:'Tourisme et projets pour 2027', summary:'Cuisine extérieure à Testarouman, réflexion sur une aire de camping-cars, gîtes forestiers et parcours Terra Aventura.', result:'Information donnée', vote:'Pas de vote', opinion:'Ces pistes recoupent plusieurs promesses de la majorité. Elles doivent maintenant être chiffrées, priorisées et reliées à une stratégie touristique claire.', theme:'Tourisme & attractivité' },
      { ref:'E', kind:'Information', title:'Voirie, centre-bourg et voie douce', summary:'Des travaux de chaussée sont évoqués et un plan de sécurisation de la RD 834 et des déplacements doux est présenté.', result:'Information donnée', vote:'Pas de vote', opinion:'Le sujet est commun aux deux programmes. Nous attendons un projet d’ensemble, un calendrier et un plan de financement.', theme:'Centre-bourg & mobilités' }
    ]
  },
  {
    id: 'avril-2026', date: '27 avril 2026', headline: '10 délibérations',
    stats: ['8 unanimes', '2 avec abstentions', 'questions diverses'], open: false,
    pdf: 'assets/documents/pv-conseil-27-avril-2026.pdf',
    intro: 'Budgets 2026, fiscalité, forêt, santé, emplois saisonniers et échanges sur les projets municipaux.',
    items: [
      { ref:'01', kind:'Délibération', title:'Budget 2026 de la commune', summary:'1 641 587,24 € d’investissements, 1 712 969,94 € de dépenses de fonctionnement et 2 400 350,95 € de recettes de fonctionnement.', result:'15 pour · 4 abstentions', vote:'Abstention', opinion:'Adrien Tordeur, Paul Arnaldo, Cassandra Decertaines et Mélanie Clark se sont abstenus. Des réponses restaient à préciser sur les emplois, le terrain Sentucq, l’excédent et les priorités d’investissement.', theme:'Gouvernance & transparence' },
      { ref:'02', kind:'Délibération', title:'Budget 2026 du CADT', summary:'101 006,68 € d’investissements, 413 374,11 € de dépenses de fonctionnement et 419 740 € de recettes.', result:'15 pour · 4 abstentions', vote:'Abstention', opinion:'Les quatre élus de Pissos en Action se sont abstenus. Nous demandons un diagnostic et une stratégie claire pour les gîtes, le camping et les équipements touristiques.', theme:'Tourisme & attractivité' },
      { ref:'03', kind:'Délibération', title:'Taux des taxes locales', summary:'Les taux restent à 26,94 % pour le foncier bâti, 20,32 % pour le non-bâti et 13,67 % pour les résidences secondaires.', result:'Unanimité', vote:'Pour', opinion:'Le maintien des taux évite une hausse automatique de la fiscalité locale.', theme:'Gouvernance & transparence' },
      { ref:'04', kind:'Délibération', title:'Exploitation des bois après la tempête Nils', summary:'Une convention avec l’ONF organise l’exploitation groupée des arbres touchés.', result:'Unanimité', vote:'Pour', opinion:'Il fallait valoriser les bois tombés et limiter les risques, avec l’expertise de l’ONF.', theme:'Environnement, énergie & forêt' },
      { ref:'05', kind:'Délibération', title:'Programme 2026 des coupes de bois', summary:'L’état d’assiette des coupes est adapté après les dégâts de la tempête.', result:'Unanimité', vote:'Pour', opinion:'Nous suivrons les recettes, les coûts d’exploitation et la remise en état.', theme:'Environnement, énergie & forêt' },
      { ref:'06', kind:'Délibération', title:'Bail du local de l’ostéopathe', summary:'Un bail de six ans est conclu pour 350 € par mois, hors charges.', result:'Unanimité', vote:'Pour', opinion:'Nous soutenons la continuité du service. Adrien Tordeur a demandé si des horaires plus larges pouvaient être recherchés.', theme:'Proximité & sécurité' },
      { ref:'07', kind:'Délibération', title:'Redevance versée par Orange', summary:'Orange versera 3 378,58 € pour l’occupation du domaine public.', result:'Unanimité', vote:'Pour', opinion:'Il est normal que la commune perçoive cette redevance.', theme:'Gouvernance & transparence' },
      { ref:'08', kind:'Délibération', title:'Emploi technique temporaire', summary:'Création d’un poste à temps complet pendant douze mois pour l’entretien des bâtiments.', result:'Unanimité', vote:'Pour', opinion:'Le renfort répond à un besoin. Son coût et la suite donnée après douze mois devront être évalués.', theme:'Gouvernance & transparence' },
      { ref:'09', kind:'Délibération', title:'Quatorze emplois saisonniers', summary:'Les postes permettront d’ouvrir et d’entretenir les équipements touristiques pendant la saison.', result:'Unanimité', vote:'Pour', opinion:'Nous avons demandé une répartition précise des postes et de leurs lieux d’affectation.', theme:'Tourisme & attractivité' },
      { ref:'10', kind:'Délibération', title:'Six stagiaires du CREPS', summary:'Six stagiaires BPJEPS seront accueillis et gratifiés 4,50 € par heure.', result:'Unanimité', vote:'Pour', opinion:'Le dispositif renforce l’encadrement sportif estival et offre une expérience professionnelle aux stagiaires.', theme:'Enfance & jeunesse' },
      { ref:'A', kind:'Question diverse', title:'Terrain Sentucq et liaison douce', summary:'Adrien Tordeur interroge la majorité sur l’achat ou l’usage du terrain Sentucq pour une liaison douce.', result:'Échange en séance', vote:'Pas de vote', opinion:'La liaison douce doit s’inscrire dans un projet cohérent pour le centre-bourg, avec coût, tracé et calendrier.', theme:'Centre-bourg & mobilités' },
      { ref:'B', kind:'Question diverse', title:'Gîtes de Richet et piscine', summary:'Cassandra Decertaines demande où en sont l’estimation des gîtes et l’ouverture de la piscine.', result:'Échange en séance', vote:'Pas de vote', opinion:'Le maire évoque environ 300 000 € de réparations pour la piscine, des études en septembre et des travaux au premier semestre 2027.', theme:'Tourisme & attractivité' },
      { ref:'C', kind:'Information', title:'Commissions intercommunales', summary:'Les représentants du conseil dans les commissions intercommunales sont désignés.', result:'Information donnée', vote:'Pas de vote', opinion:'Ces représentations doivent permettre à Pissos de défendre ses projets et d’en rendre compte aux habitants.', theme:'Gouvernance & transparence' }
    ]
  }
];

const themes = [
  { name:'Centre-bourg & mobilités', majority:'Apaiser la circulation, créer une liaison douce et réaménager les espaces du centre-bourg.', ours:'Construire un projet global : traversées, stationnement, cheminements, espaces publics et soutien aux commerces.' },
  { name:'Enfance & jeunesse', majority:'Développer l’accueil de loisirs, une aire de jeux, le city-stade et un conseil municipal des jeunes.', ours:'Créer des solutions pour les collégiens, un conseil des jeunes doté d’un budget et des actions de prévention.' },
  { name:'Tourisme & attractivité', majority:'Moderniser la piscine et Testarouman, travailler sur les gîtes, les camping-cars et Terra Aventura.', ours:'Évaluer le CADT et chaque équipement, fixer des objectifs et bâtir une stratégie touristique soutenable.' },
  { name:'Environnement, énergie & forêt', majority:'Rénover les bâtiments, réduire l’éclairage, préserver la biodiversité et gérer la forêt de façon raisonnée.', ours:'Mesurer les économies, cibler les travaux et articuler sécurité, écologie et résultats économiques de la forêt.' },
  { name:'Proximité & sécurité', majority:'Relancer les référents de quartier, soutenir la réserve communale et renforcer la vigilance citoyenne.', ours:'Développer la prévention, l’information des habitants, la préparation aux crises et la proximité.' },
  { name:'Patrimoine & vie locale', majority:'Poursuivre Richet, les actions culturelles et l’entretien du patrimoine communal.', ours:'Entretenir le patrimoine avec des priorités, des coûts, des financements et des calendriers clairement annoncés.' },
  { name:'Gouvernance & transparence', majority:'Conduire le mandat dans le dialogue, l’écoute et l’intérêt des habitants.', ours:'Expliquer les décisions, rendre les budgets lisibles et permettre aux habitants de suivre l’action municipale.' }
];

const allItems = sessions.flatMap(session => session.items.map(item => ({...item, date:session.date})));
const esc = value => String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
const voteClass = vote => vote === 'Pour' ? 'for' : vote === 'Abstention' ? 'abstain' : 'neutral';

function agendaItem(item) {
  return `<details class="agenda-item"><summary><span class="item-ref">${esc(item.ref)}</span><div><small>${esc(item.kind)}</small><strong>${esc(item.title)}</strong></div><span class="vote-pill ${voteClass(item.vote)}">${esc(item.vote)}</span><b aria-hidden="true">+</b></summary><div class="agenda-detail"><div><small>Ce qui s’est passé</small><p>${esc(item.summary)}</p><span class="result-line">Résultat : <strong>${esc(item.result)}</strong></span></div><div class="opinion"><small>Notre avis</small><p>${esc(item.opinion)}</p><span>${esc(item.theme)}</span></div></div></details>`;
}

function renderSessions() {
  document.querySelector('#sessionList').innerHTML = sessions.map(session => `<details class="council-session reveal" ${session.open ? 'open' : ''} id="${session.id}"><summary><div class="session-date"><small>Séance du</small><h3>${esc(session.date)}</h3><p>${esc(session.intro)}</p></div><div class="session-stats">${session.stats.map(stat => `<span>${esc(stat)}</span>`).join('')}<b aria-hidden="true">+</b></div></summary><div class="session-body"><aside><span>${esc(session.headline)}</span><p>Les élus de Pissos en Action expliquent leur vote et les points qu’ils souhaitent suivre.</p><a href="${session.pdf}" target="_blank" rel="noopener">Lire le PV complet ↗</a></aside><div class="agenda-list">${session.items.map(agendaItem).join('')}</div></div></details>`).join('');
}

function themeItem(theme, index) {
  const items = allItems.filter(item => item.theme === theme.name);
  const votes = items.reduce((acc, item) => { acc[item.vote] = (acc[item.vote] || 0) + 1; return acc; }, {});
  const tally = [['Pour',votes.Pour],['Abstention',votes.Abstention],['Sans vote',votes['Pas de vote']]].filter(x => x[1]).map(x => `${x[1]} ${x[0].toLowerCase()}`).join(' · ');
  return `<details class="theme-item reveal"><summary><span class="theme-index">0${index + 1}</span><div><small>Thème commun aux deux programmes</small><strong>${esc(theme.name)}</strong></div><div class="theme-count"><b>${items.length}</b><span>sujet${items.length > 1 ? 's' : ''}<small>${esc(tally)}</small></span></div><i aria-hidden="true">+</i></summary><div class="theme-body"><div class="commitments"><section><small>Programme de la majorité</small><p>${esc(theme.majority)}</p></section><section><small>Programme de Pissos en Action</small><p>${esc(theme.ours)}</p></section></div><div class="theme-decisions">${items.map(item => `<article><div class="decision-head"><span>${esc(item.date)}</span><span class="vote-pill ${voteClass(item.vote)}">${esc(item.vote)}</span></div><h4>${esc(item.title)}</h4><p>${esc(item.opinion)}</p></article>`).join('')}</div></div></details>`;
}

function renderThemes() {
  const comparedItems = themes.reduce((n, theme) => n + allItems.filter(item => item.theme === theme.name).length, 0);
  document.querySelector('#compareSummary').innerHTML = `<div><b>${themes.length}</b><span>familles communes</span></div><div><b>${comparedItems}</b><span>sujets évoqués</span></div><p>Cliquez sur un thème pour voir les engagements, les votes et notre position.</p>`;
  document.querySelector('#themeList').innerHTML = themes.map(themeItem).join('');
}

document.addEventListener('DOMContentLoaded', () => {
  renderSessions(); renderThemes();
  const navbar = document.querySelector('#navbar');
  const backToTop = document.querySelector('#backToTop');
  const hamburger = document.querySelector('#hamburger');
  const mobileNav = document.querySelector('#mobileNav');
  const onScroll = () => { navbar.classList.toggle('scrolled', scrollY > 15); backToTop.classList.toggle('visible', scrollY > 500); };
  addEventListener('scroll', onScroll, {passive:true}); onScroll();
  hamburger.addEventListener('click', () => { const open = hamburger.classList.toggle('active'); mobileNav.classList.toggle('open', open); hamburger.setAttribute('aria-expanded', open); });
  mobileNav.addEventListener('click', event => { if (event.target.matches('a')) { hamburger.classList.remove('active'); mobileNav.classList.remove('open'); hamburger.setAttribute('aria-expanded','false'); } });
  backToTop.addEventListener('click', () => scrollTo({top:0, behavior:'smooth'}));
  const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); } }), {threshold:.08});
  document.querySelectorAll('.reveal').forEach(element => observer.observe(element));
});
